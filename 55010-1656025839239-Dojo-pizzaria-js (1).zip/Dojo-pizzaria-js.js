function pizzaOven (crustType,sauceType,cheeses,toppings) {
    var pizza = {};        //use {} to create an empty object!!
    pizza.crustype = crustType;
    pizza.sauceType = sauceType;
    pizza.cheeses = cheeses;
    pizza.toppings = toppings;
    return pizza
}
var p1 = pizzaOven("deep dish","traditional", ["mozzarella"],["pepperoni", "sausage"])
console.log(p1);

var p2 = pizzaOven("hand tossed","marinara",["mozzarella","feta"], ["mushrooms","olives","onions"])
console.log(p2);


var p3 = pizzaOven("thin crust","tomato basil",["mozzarella"],["jalapeno","bell pepper","veggies"])
console.log(p3);

var p4 = pizzaOven("thick crust","no sauce",["no cheese"],["left beef"])
console.log(p4);

// //bonus



const crust = ["thick","thin","gluten free"];
const cheeses = ["mozzarella","american","nacho","feta","Brie"];
const sauce = ["marinara","pesto","alfredo","none"];
const topping = ["onion","tomato","olive","pepperoni","veggies","none"];

function randomPi(crustType,sauceType,cheeses,toppings,toppings2){
    var pizza = {};
    pizza.crustype = crustType;
    pizza.cheeses = cheeses;
    pizza.sauceType = sauceType;
    pizza.toppings = toppings;
    pizza.toppings2 = toppings2;
    return pizza
}

// var pizz = randomPi(crust[Math.floor(Math.random()*crust.length)])
// console.log(pizz) TEST RUN FOR MATH.RANDOM

var pizz = randomPi(crust[Math.floor(Math.random()*crust.length)],cheeses[Math.floor(Math.random()*cheeses.length)],sauce[Math.floor(Math.random()*sauce.length)],topping[Math.floor(Math.random()*topping.length)],topping[Math.floor(Math.random()*topping.length)])
console.log(pizz)
//ADDED EXTRA TOPPINGS OPTION AND NONE TO THE ARRAY INCASE THEY WANT 0-2 TOPPINGS!!!
//math.random() gives random int between 0 - 1, multiplied by the length of the array to get potential int then we round DOWN
// math.floor rounds downwardd!!! to nearest int!!! helps us stay in the array!